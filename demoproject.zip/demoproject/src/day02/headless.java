package day02;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.safari.SafariOptions;

public class headless {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ChromeOptions cc=new ChromeOptions();
SafariOptions ss=new SafariOptions();
FirefoxOptions ff=new FirefoxOptions();
cc.addArguments("Incognito");
ff.addArguments("Incognito");

WebDriver d1= new ChromeDriver(cc);
d1.get("https://www.google.com");
System.out.println(d1.getTitle());
d1.get("https://www.youtube.com");
System.out.println(d1.getTitle());


	}

}

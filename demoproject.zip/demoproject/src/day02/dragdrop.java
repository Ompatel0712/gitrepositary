package day02;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import com.google.common.io.Files;

public class dragdrop {

	public static void main(String[] args) throws InterruptedException, IOException {
		// TODO Auto-generated method stub
//WebDriver d1=new ChromeDriver();
WebDriver d2=new ChromeDriver();
//d1.manage().window().maximize();
//d1.get("https://demo.automationtesting.in/Static.html");
//WebElement obj=d1.findElement(By.id("mongo"));
//WebElement obj1=d1.findElement(By.id("droparea"));
//
//Actions s=new Actions(d1);
//s.dragAndDrop(obj, obj1).build().perform();
d2.manage().window().maximize();
d2.get("https://demo.guru99.com/test/drag_drop.html");

WebElement obj=d2.findElement(By.id("fourth"));
WebElement obj1=d2.findElement(By.id("amt7"));
Thread.sleep(2000);
Actions s=new Actions(d2);
s.dragAndDrop(obj, obj1).build().perform();

File screenshot=((TakesScreenshot)d2).getScreenshotAs(OutputType.FILE);
Files.copy(screenshot,new File("C:\\Users\\CDAC\\Desktop\\SDLC\\scr.png"));
	}
}

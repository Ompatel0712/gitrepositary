package day02;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;

public class web {
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
WebDriver d1=new ChromeDriver();

d1.manage().window().maximize();
String s=d1.getWindowHandle();
d1.get("https://www.google.com/search?q=email&rlz=1C1CHZN_enIN1022IN1022&oq=email&gs_lcrp=EgZjaHJvbWUyBggAEEUYOTIHCAEQABiPAjIHCAIQABiPAjIGCAMQRRg8MgYIBBBFGDwyBggFEEUYPNIBCTE1NThqMGoxNagCCLACAfEF-17f7yDEgfc&sourceid=chrome&ie=UTF-8");
d1.switchTo().newWindow(WindowType.TAB);
String s1=d1.getWindowHandle();
d1.get("https://www.google.com");
d1.switchTo().newWindow(WindowType.TAB);
String s2=d1.getWindowHandle();
d1.get("https://www.youtube.com/watch");
d1.switchTo().window(s1);
Thread.sleep(2000);
d1.switchTo().window(s);
Thread.sleep(2000);
d1.switchTo().window(s2);
Thread.sleep(2000);
d1.close();
	}
}

package day02;

import java.awt.Desktop.Action;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class actionmoment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
WebDriver d1=new ChromeDriver();
d1.manage().window().maximize();
d1.get("https://accounts.saucelabs.com/am/XUI/#login/");
WebElement obj=d1.findElement(By.id("idToken1"));
Actions s=new Actions(d1);
s.moveToElement(obj).contextClick().build().perform();
obj.sendKeys("ABCD");
s.doubleClick(obj).build().perform();

	}

}

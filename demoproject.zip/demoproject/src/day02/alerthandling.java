package day02;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class alerthandling {
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		
		WebDriver d1=new ChromeDriver();

		d1.manage().window().maximize();
		d1.get("https://demo.automationtesting.in/Alerts.html");
//		d1.findElement(By.xpath("//button[@class='btn btn-danger']")).click();
//		Thread.sleep(2000);
//		Alert obj=d1.switchTo().alert();
//		System.out.println(obj.getText());
//		obj.accept();
		
		d1.findElement(By.xpath("//a[@href='#CancelTab']")).click();
		d1.findElement(By.xpath("//button[@class='btn btn-primary']")).click();
		
		Thread.sleep(2000);
		Alert obj=d1.switchTo().alert();
		System.out.println(obj.getText());
		obj.dismiss();
		WebElement s=d1.findElement(By.id("demo"));
		System.out.println(s.getText());
		
	}
}

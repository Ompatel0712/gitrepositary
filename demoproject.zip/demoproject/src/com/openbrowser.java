package com;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.safari.SafariDriver;

public class openbrowser {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver d1=new ChromeDriver();
//		WebDriver d2=new FirefoxDriver();
//		d2.get("https://mail.google.com");
		d1.get("https://www.google.com");
		
//		String s=d1.getTitle();
//		String s1=d2.getTitle();
//		Thread.sleep(2000);
//		d2.navigate().back();
//		d2.navigate().forward();
//		d2.navigate().refresh();
//		
//		d1.manage().window().maximize();
//		d2.manage().window().minimize();
//		
//	
//		System.out.println(d1.getTitle());
//		System.out.println(d2.getTitle());
//		System.out.println((s.equalsIgnoreCase(s1)));
//		System.out.println(d1.manage().window().getSize());
		
		
		Dimension d=new Dimension(500, 850);{	
			d1.manage().window().setSize(d);
		}
	}
}
